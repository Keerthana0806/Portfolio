const projects = [
  {
    id: 'aeroponics',
    title: 'Aeroponics Vertical Farming',
    subtitle: 'IoT + Sensors | Funded by IEEE & IIT Madras',
    short: 'A vertical aeroponics tower with sensor monitoring, nutrient control and water recycling targeted for SHG women empowerment.',
    long: 'My project is an Automated Aeroponics Vertical Tower Farming System, designed to grow plants using no soil, 90% less water, and in a limited area, yet achieving a higher yield compared to traditional farming. The system uses vertical towers connected to a purified water source, nutrient container, and recirculation system. First, water passes through a softener, then mixes with nutrients in the nutrient container. A pump, controlled by a timer, pushes this solution through pipelines to sprinklers at the top of each tower, which spray the nutrient-rich mist directly onto plant roots. The excess solution drains back into the reservoir, making the system highly water-efficient. For automation, a Microcontroller Unit (MCU) is placed near the nutrient container and connected to sensors like pH and TDS/EC, which monitor acidity and nutrient concentration. The MCU processes this data, displays it on an LCD, and can also transmit it to a real-time IoT dashboard. Based on calibration, if any parameter goes out of range, the system alerts the user and corrective actions can be taken. One of the highlights of our project is the involvement of women Self-Help Groups (SHGs). Since the system is automated and easy to manage, SHG members are trained to operate and maintain it, giving them both financial independence and a chance to contribute to sustainable farming for the community.',
    repo: 'https://github.com'
  },

  {
    id: 'uowc',
    title: 'Underwater Optical Wireless Communication',
    subtitle: 'Research Project | Optical Communication',
    short: 'Visible-light underwater communication study – attenuation analysis, BER simulations and small-range prototype.',
    long: 'My project is based on Underwater Optical Wireless Communication, where we focused on transmitting text and audio through water using visible light. The complete work was divided into three phases. In Phase 1, we analyzed how light behaves underwater by studying absorption, scattering, and attenuation effects across different water types such as clear seawater, ocean water, coastal water, and turbid water. This helped us understand how water clarity directly affects signal strength, distance, and Bit Error Rate. In Phase 2, we designed a general optical communication circuit in OptiSystem consisting of a transmitter block, an underwater channel block, and a receiver block. Instead of focusing on different modulation schemes, our aim in OptiSystem was to vary the attenuation constant inside the channel and observe how the BER changes with increasing attenuation and distance. This simulation validated our theoretical analysis by clearly showing that clearer water gives very low BER, while turbid water rapidly increases BER due to high scattering and absorption. Finally, in Phase 3, we implemented the system as a hardware prototype using Arduino. At the transmitter side, we used a keyboard for text and an audio jack for audio input. The Arduino converted the input into binary and modulated it onto an LED using simple intensity-based modulation. The modulated light traveled through water and was detected at the receiver side by a photodiode, which converted the optical signal back into electrical form. The receiving Arduino decoded the text and displayed it on an LCD, and in audio mode it amplified and played the audio signal through a speaker. The prototype successfully demonstrated real-time underwater communication and matched the trends we observed in OptiSystem. Overall, by combining theoretical analysis, simulation, and practical implementation, we were able to prove that visible-light-based communication can be a fast, reliable, and efficient alternative to acoustic or RF communication in underwater environments.',
    repo: 'https://github.com'
  }
]

export default projects
