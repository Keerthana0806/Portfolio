import React from 'react'
import { Link, NavLink } from 'react-router-dom'
import styled from 'styled-components'

const HeaderEl = styled.header`
  box-shadow: none;
`

export default function Header() {
  return (
    <HeaderEl className="site-header">
      <div className="header-inner">
        <div className="brand">
          <Link to="/" style={{ textDecoration: 'none', color: '#111' }}>
            <div className="name">Keerthana S</div>
          </Link>
          <div className="tag" style={{background:'darkblue',color:'white'}}>ECE Graduate • Embedded & IoT • MERN Learner</div>
        </div>

        <nav className="nav" aria-label="main navigation">
          <NavLink to="/" end>Home</NavLink>
          <NavLink to="/about">About</NavLink>
          <NavLink to="/education">Education</NavLink>
          <NavLink to="/skills">Skills</NavLink>
          <NavLink to="/experience">Experience</NavLink>
          <NavLink to="/projects">Projects</NavLink>
          <NavLink to="/achievements">Achievements</NavLink>
          <NavLink to="/contact">Contact</NavLink>
        </nav>
      </div>
    </HeaderEl>
  )
}
