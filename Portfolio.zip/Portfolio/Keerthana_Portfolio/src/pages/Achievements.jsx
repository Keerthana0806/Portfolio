import React from 'react'

export default function Achievements(){
  return (
    <div className="container">
      <h1 className="h1">Achievements</h1>

      <div className="card" style={{ marginBottom: 12 }}>
        <h2 className="h2" style={{color:'darkblue'}}>Funding</h2>
        <ul className="list-compact">
          <li>IEEE SIGHT (Tech4Good) — $4,200 for Aeroponics project</li>
          <li>IIT Madras (Ideas to Impact) — ₹50,000 for Aeroponics project</li>
        </ul>
      </div>

      <div className="card" style={{ marginBottom: 12 }}>
        <h2 className="h2" style={{color:'darkblue'}}>Competitions & Exams</h2>
        <ul className="list-compact">
          <li>1st Prize — Paper Presentation (Aeroponics)</li>
          <li>Cleared GATE 2024 — Score: 355</li>
          
        </ul>
      </div>

      <div className="card">
        <h2 className="h2" style={{color:'darkblue'}}>Certifications</h2>
        <ul className="list-compact">
          <li>CCNA (Networking)</li>
          <li>NPTEL Silver certificates — Computer Networks </li>
          <li>Arduino, C, Python — Spoken Tutorial</li>
          <li>IOT and Embedded Systems — Value Added Course</li>
        </ul>
      </div>
    </div>
  )
}
