import React, { useState } from "react";

export default function Contact() {
  const [status, setStatus] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();

    const formData = {
      name: e.target.name.value,
      email: e.target.email.value,
      message: e.target.message.value,
    };

    console.log("Sending:", formData);

    const res = await fetch("http://localhost:5000/send-message", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(formData),
    });

    const data = await res.json();
    alert(data.message);
  };

  return (
    <div className="container">
      <h1 className="h1">Contact</h1>

      <div
        className="card"
        style={{ display: "grid", gridTemplateColumns: "1fr 340px", gap: 20 }}
      >
        <div>
          <form onSubmit={handleSubmit}>
            <div style={{ marginBottom: 10 }}>
              <label className="small">Name</label>
              <br />
              <input
                className="input"
                name="name"
                style={{ width: "100%", padding: 10, marginTop: 6 }}
                required
              />
            </div>

            <div style={{ marginBottom: 10 }}>
              <label className="small">Email</label>
              <br />
              <input
                className="input"
                name="email"
                type="email"
                style={{ width: "100%", padding: 10, marginTop: 6 }}
                required
              />
            </div>

            <div style={{ marginBottom: 10 }}>
              <label className="small">Message</label>
              <br />
              <textarea
                name="message"
                style={{ width: "100%", padding: 10, marginTop: 6 }}
                rows="6"
                required
              />
            </div>

            <button className="btn-primary btn" type="submit" style={{}}>
              Send Message
            </button>

            {status && <p style={{ marginTop: "12px" }}>{status}</p>}
          </form>
        </div>

        <aside>
          <div className="small">Email</div>
          <div style={{ marginBottom: 12, fontWeight: 600 }}>
            anandhikeerthana08@gmail.com
          </div>

          <div className="small">Phone</div>
          <div style={{ marginBottom: 12, fontWeight: 600 }}>6382477438</div>

          <div className="small">LinkedIn</div>
          <a
            className="btn"
            href="https://www.linkedin.com/in/keerthana-s-014093228"
            target="_blank"
            rel="noreferrer"
          >
            View profile
          </a>
        </aside>
      </div>
    </div>
  );
}
