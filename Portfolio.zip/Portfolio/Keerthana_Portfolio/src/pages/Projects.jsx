import React, { useState } from "react";
import projects from "../data/projects";
import styled from "styled-components";

const ProjectGrid = styled.div`
  display: grid;
  grid-template-rows: repeat(auto-fit, minmax(260px, 1fr));
  gap: 16px;
`;

const GitBtn = styled.a`
 display: inline-flex;      /* stays small */
  justify-content: center;
  align-items: center;
/* FIX — stops flex parent from expanding it */
  align-self: center;
  padding: 8px 14px;
  background: green;
  color: white;
  border-radius: 6px;
  text-decoration: none;
  font-size: 15px;
  
 


  &:hover {
    opacity: 0.9;
  }
`;

const ReadBtn = styled.button`
  margin-right:10px;
  margin-bottom:20px;
  background: none;
  border: none;
  color: #4b61ff;
  cursor: pointer;
  font-size: 14px;
  padding: 0;

  &:hover {
    text-decoration: underline;
  }
`;

export default function Projects() {
  return (
    <div className="container">
      <h1 className="h1">Projects</h1>

      <ProjectGrid>
        {projects.map((p) => (
          <ProjectCard key={p.id} project={p} />
        ))}
      </ProjectGrid>
    </div>
  );
}

function ProjectCard({ project }) {
  const [expanded, setExpanded] = useState(false);

  return (
    <div className="card" style={{minHeight:260,display:"flex",flexDirection:"column",justifyContent:"space-between"}}>
      <div style={{ fontWeight: 700 }}>{project.title}</div>

      <div className="small-muted" style={{ marginTop: 6 }}>
        {project.subtitle}
      </div>

      {/* SHORT or FULL description based on toggle */}
      <p style={{ marginTop: 8 }}>
        {expanded ? project.long : project.short}
      </p>

      {/* READ MORE / READ LESS BUTTON */}
      <ReadBtn onClick={() => setExpanded(!expanded)}>
        {expanded ? "Read Less..." : "Read More..."}
      </ReadBtn>

      {/* GITHUB BUTTON */}
      <GitBtn
        href={project.repo}
        target="_blank"
        rel="noreferrer"
      >
        GitHub Link
      </GitBtn>
    </div>
  );
}


