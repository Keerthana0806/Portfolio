import React from "react";
import styled from "styled-components";
import heroImg from "../assets/hero.png"; // ← place your image inside /src/assets

const HomeContainer = styled.section`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 60px 0;
`;

const Left = styled.div`
  flex: 1;

  h2 {
    font-size: 40px;
    font-weight: 700;
    margin: 0;
  }

  h1 {
    font-size: 48px;
    font-weight: 800;
    margin: 20px 0;
  }

  h1 span {
    color: orange;
  }

  h3 {
    font-size: 32px;
    font-weight: 600;
    margin-bottom: 20px;
  }
`;

const ContactBtn = styled.a`
  display: inline-block;
  margin-top: 20px;
  background: darkblue;
  padding: 12px 28px;
  color: white;
  border-radius: 8px;
  box-shadow: 0 4px 8px rgba(0,0,0,0.1);
  font-size: 16px;
  text-decoration: none;

  &:hover {
    opacity: 0.9;
    color:white;
  }
`;

const Right = styled.div`
  flex: 1;
  display: flex;
  justify-content: center;

  img {
    width: 420px;
  }
`;

const SocialRow = styled.div`
  margin-top: 40px;
  display: flex;
  gap: 18px;
  font-size: 24px;

  a {
    color: #111;
    text-decoration: none;
  }

  a:hover {
    color: #4b61ff;
  }
`;

export default function Home() {
  return (
    <div className="container">
      <HomeContainer>
        {/* LEFT SIDE */}
        <Left>
          <h2>Hi,</h2>
          <h1>
            I'm <span>Keerthana S</span>
          </h1>
          <h3>Electronics Engineer & IoT Developer</h3>

          <ContactBtn href="/about">About Me</ContactBtn>


          {/* SOCIAL LINKS */}
          {/* <SocialRow>
            
            <a href="https://github.com" target="_blank">🐱</a>
          
            <a href="https://linkedin.com/in/keerthana-s-014093228" target="_blank">📱</a>
          </SocialRow> */}
        </Left>

        {/* RIGHT SIDE */}
        <Right>
          <img src={heroImg} alt="illustration" />
        </Right>
      </HomeContainer>
    </div>
  );
}

