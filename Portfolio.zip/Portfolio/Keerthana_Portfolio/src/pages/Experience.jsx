import React from 'react'
import projects from '../data/projects'

export default function Experience(){
  return (
    <div className="container">
      <h1 className="h1">Experience</h1>

      <div className="card" style={{ marginBottom: 12 }}>
        <h2 className="h2" style={{color:'darkblue'}}>Customer Success Manager — Maestrominds</h2>
        <div className="small-muted">Dec 2023-July 2025</div>
        <ul className="list-compact">
          <li>Managed client onboarding and project delivery.</li>
          <li>Coordinated between technical teams and clients to define scope.</li>
          <li>Improved customer retention through timely communication & reporting.</li>
        </ul>
      </div>

           <div className="card" style={{ marginBottom: 12 }}>
        <h2 className="h2" style={{color:'darkblue'}}>Cisco Networking Academy — Cybersecurity (Virtual)</h2>
        <div className="small-muted">01/09/2023 to 30/09/2023</div>
        <ul className="list-compact">
          <li>Completed modules on network security and protection fundamentals.</li>
          <li>Worked with Cisco Packet Tracer to simulate real-time networks, configure routers, switches, VLANs, DHCP, and static & dynamic routing.</li>
          <li><b>Project: </b>Designed a network topology for Sri Sairam Engineering College, ensuring efficient connectivity across various campus departments. This involved configuring routers, switches, and servers to establish seamless data communication. </li>
        </ul>
      </div>

         <div className="card" style={{ marginBottom: 12 }}>
        <h2 className="h2" style={{color:'darkblue'}}>Jorim Technology Solutions Pvt. Ltd.</h2>
        <div className="small-muted">28/08/2023 to 22/09/2023</div>
        <ul className="list-compact">
          <li>Learned fundamentals of web development including HTML, CSS, JavaScript, and React.js. </li>
          <li>Developed a functional and responsive login page with user authentication features, improving secure access. And designed an Autism Finding Form to assist parents in evaluating behavioral patterns in children which involves implementation a structured questionnaire to collect relevant data for early autism detection.
</li>
<li>Gained hands-on experience with real client projects like hospital website development. </li>
        </ul>
      </div>
    

      <div className="card" style={{ marginBottom: 12 }}>
        <h2 className="h2" style={{color:'darkblue'}}>Telecommunication Intern — NLC India Ltd</h2>
        <div className="small-muted">10/06/2024 to 22/09/2024</div>
        <ul className="list-compact">
          <li>Exposure to fiber optics, EPABX, SCADA and industrial wireless systems.</li>
          <li>Field-level troubleshooting and monitoring experiments.</li>
        </ul>
      </div>

  
    </div>
  )
}
