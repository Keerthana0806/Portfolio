import React from 'react'
import styled from 'styled-components'

const SkillRow = styled.div`
  display:flex;
  align-items:center;
  justify-content:space-between;
  margin-top:20px;
  padding:10px;
  background:rgba(23, 59, 109, 1);
`
const Bar = styled.div`
  height:10px;
  background:#e6e6f0;
  border-radius:8px;
  overflow:hidden;
  margin-left:12px;
  flex:1;
`
const BarFill = styled.div`
  height:100%;
  background: #4DB5FF;
  width: ${p => p.width || '50%'};
`

export default function Skills(){
  return (
    <div className="container">
      <h1 className="h1">Skills</h1>

      <div className="card">
        <div>
          <h2 className="h2" style={{color:'darkblue'}} >Technical Skills</h2>

          <SkillRow>
            <div style={{width:180,color:'white'}}>C programming,Python language</div>
            <Bar><BarFill width="90%" /></Bar>
          </SkillRow>

          <SkillRow>
            <div style={{width:180,color:'white'}}>IOT using Arduino</div>
            <Bar><BarFill width="80%" /></Bar>
          </SkillRow>

          <SkillRow>
            <div style={{width:180,color:'white'}}>Networking (CCNA)</div>
            <Bar><BarFill width="70%" /></Bar>
          </SkillRow>

          <SkillRow>
            <div style={{width:180,color:'white'}}>Web Development (React, Node)</div>
            <Bar><BarFill width="65%" /></Bar>
          </SkillRow>

          <SkillRow>
            <div style={{width:180,color:'white'}}>Design and Presentation</div>
            <Bar><BarFill width="80%" /></Bar>
          </SkillRow>
        </div>
        <div style={{marginTop: 18}}>
          <h2 className="h2" style={{color:'darkblue'}}>Others Skills</h2>
            <SkillRow>
            <div style={{width:180,color:'white'}}>Teamwork</div>
            <Bar><BarFill width="100%" /></Bar>
          </SkillRow>

          <SkillRow>
            <div style={{width:180,color:'white'}}>Leadership</div>
            <Bar><BarFill width="90%" /></Bar>
          </SkillRow>

          <SkillRow>
            <div style={{width:180,color:'white'}}>Organizing events</div>
            <Bar><BarFill width="100%" /></Bar>
          </SkillRow>
        </div>

        <div style={{ marginTop: 18 }}>
          <h2 className="h2" style={{color:'darkblue'}}>Tools & Platforms</h2>
          <div className="row" style={{ marginTop: 8 }}>
            <span className="tag">Arduino IDE</span>
            <span className="tag">OptiSystem</span>
            <span className="tag">Git</span>
            <span className="tag">VS Code</span>
            <span className="tag">MongoDB</span>
          </div>
        </div>
      </div>
    </div>
  )
}
