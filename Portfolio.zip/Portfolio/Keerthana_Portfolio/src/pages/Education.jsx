import React from 'react'

export default function Education(){
  return (
    <div className="container">
      <h1 className="h1">Education</h1>

      <div className="card" style={{ marginBottom: 14 }}>
        <h2 className="h2" style={{color: 'darkblue'}}>Bachelor of Engineering — ECE</h2>
        <p className="small-muted">Sri Sairam Engineering College</p>
        <p style={{ marginTop: 8 }}>CGPA: <strong>8.68</strong></p>

      </div>

      <div className="card" style={{ marginBottom: 14 }}>
        <h2 className="h2" style={{color: 'darkblue'}}>Higher Secondary (HSC)</h2>
        <p className="small-muted">Bharathi Matriculation Higher Secondary School</p>
        <p style={{ marginTop: 8 }}>Percentage: <strong>96.1%</strong></p>
      </div>

      <div className="card">
        <h2 className="h2" style={{color: 'darkblue'}}>SSLC</h2>
        <p className="small-muted">Bharathi Matriculation Higher Secondary School</p>
        <p style={{ marginTop: 8 }}>Percentage: <strong>95.4%</strong></p>
      </div>
    </div>
  )
}
