import React from "react";
import styled from "styled-components";

const AboutWrapper = styled.section`
  padding: 50px 0;
`;

const Title = styled.h1`
  font-size: 38px;
  font-weight: 800;
  margin-bottom: 20px;
  text-align: center;
  color:darkblue;
`;

const SummaryCard = styled.div`
  background: white;
  font-size: 14px;
  padding: 24px;
  border-radius: 14px;
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.08);
  margin-bottom: 28px;
`;

const InfoGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
  gap: 18px;
  
`;

const InfoBox = styled.div`
  background: white;
  padding: 18px;
  border-radius: 12px;
  box-shadow: 0 4px 14px rgba(0, 0, 0, 0.07);
`;

const Label = styled.div`
  font-size: 16px;
  font-weight: 500;
  color: darkblue;
  margin-bottom: 6px;
`;

const Value = styled.div`
  font-size: 18px;
  font-weight: 600;
  color: #111827;
`;

export default function About() {
  return (
    <AboutWrapper className="container">
      <Title>About Me</Title>

      {/* SUMMARY */}
      <SummaryCard>
        <p style={{ fontSize: "17px", color: "#374151", lineHeight: "1.6" }}>
          I am Keerthana S, a recent graduate in Electronics and Communication
          Engineering from Sri Sairam Engineering College, with a strong
          foundation in C, Python, networking, and IoT systems.My academic and
          project experience reflects a balance of both technical expertise and
          social impact. I led a socially driven project titled "Aeroponics
          Vertical Farming", which received prestigious funding from both IEEE
          SIGHT (Tech4Good Contest) and IIT Madras (Ideas to Impact Challenge),
          aimed at transforming agricultural practices using IoT and sustainable
          techniques. Additionally, I explored advanced communication systems
          through my final year project in Underwater Optical Wireless
          Communication, where I worked on high-speed laser-based data
          transmission across different water types. I’ve also served as
          a Customer Success Manager at Maestrominds, a startup,
          where I developed key professional and client-facing skills.As I
          transition into the workforce, I am actively seeking opportunities
          where I can contribute my skills, continue to learn, and grow within a
          forward-thinking company.
        </p>
      </SummaryCard>

      {/* PERSONAL INFO */}
      <InfoGrid>
        <InfoBox>
          <Label>Email</Label>
          <Value>anandhikeerthana08@gmail.com</Value>
        </InfoBox>

        <InfoBox>
          <Label>Mobile Number</Label>
          <Value>6382477438</Value>
        </InfoBox>

        <InfoBox>
          <Label>DOB</Label>
          <Value>08 June 2004</Value>
        </InfoBox>

        <InfoBox>
          <Label>Place</Label>
          <Value>Cuddalore District, Tamil Nadu</Value>
        </InfoBox>
        
       
      </InfoGrid>
    </AboutWrapper>
  );
}
