// Load env variables
require("dotenv").config();

// Import packages
const express = require("express");
const cors = require("cors");
const nodemailer = require("nodemailer");

// Create express app
const app = express();

// CORS (allow frontend)
app.use(cors({
  origin: "http://localhost:5173",
  methods: ["GET", "POST"]
}));

// Body parsers
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Test route
app.get("/", (req, res) => {
  res.send("Backend is running");
});

// CONTACT ROUTE
app.post("/send-message", async (req, res) => {
  console.log("🔥 POST /send-message called");
  console.log("BODY RECEIVED:", req.body);

  const { name, email, message } = req.body;

  if (!name || !email || !message) {
    console.log("⚠ Missing fields");
    return res.status(400).json({ message: "All fields are required" });
  }

  try {
    // Create mail transporter
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
      },
    });

    // Mail content
    const mailOptions = {
      from: `"${name}" <${email}>`,
      to: process.env.EMAIL_USER,
      subject: `Message from ${name}`,
      text: `Name: ${name}\nEmail: ${email}\nMessage:\n${message}`,
    };

    // Send mail
    await transporter.sendMail(mailOptions);

    console.log("✅ Email sent successfully!");
    res.json({ message: "Message sent successfully!" });

  } catch (err) {
    console.log("❌ Email sending failed:", err);
    res.status(500).json({ message: "Failed to send message" });
  }
});

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));

